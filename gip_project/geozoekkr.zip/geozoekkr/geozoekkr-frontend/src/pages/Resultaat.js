import React, { useEffect } from 'react';
import '../styles/style_resultaat.css';

const Resultaat = () => {
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const distance = params.get('distance');
    const score = params.get('score');
    const time = params.get('time');
    const startLat = parseFloat(params.get('startLat'));
    const startLng = parseFloat(params.get('startLng'));
    const selectedLat = parseFloat(params.get('selectedLat'));
    const selectedLng = parseFloat(params.get('selectedLng'));

    if (distance && score && time) {
      document.getElementById('distance').textContent = `${distance} km`;
      document.getElementById('score').textContent = score;
      document.getElementById('time').textContent = `${time} sec`;
    } else {
      console.error('Ongeldige of ontbrekende parameters.');
    }

    if (!isNaN(startLat) && !isNaN(startLng) && !isNaN(selectedLat) && !isNaN(selectedLng)) {
      loadGoogleMapsScript(() => {
        initMap(startLat, startLng, selectedLat, selectedLng);
      });
    }
  }, []);

  const loadGoogleMapsScript = (callback) => {
    const existingScript = document.getElementById('googleMaps');
    if (!existingScript) {
      const script = document.createElement('script');
      script.src = `https://maps.googleapis.com/maps/api/js?key=${process.env.REACT_APP_GOOGLE_MAPS_API_KEY}&libraries=&v=weekly`;
      script.id = 'googleMaps';
      document.body.appendChild(script);
      script.onload = () => {
        if (callback) callback();
      };
    } else {
      if (callback) callback();
    }
  };

  const initMap = (startLat, startLng, selectedLat, selectedLng) => {
    if (!window.google || !window.google.maps) {
      console.error('Google Maps API is not loaded.');
      return;
    }

    const startLocation = { lat: startLat, lng: startLng };
    const selectedLocation = { lat: selectedLat, lng: selectedLng };

    const map = new window.google.maps.Map(document.getElementById('map'), {
      disableDefaultUI: false,
    });

    new window.google.maps.Marker({
      position: startLocation,
      map: map,
      label: 'S',
      title: 'Startlocatie',
    });

    new window.google.maps.Marker({
      position: selectedLocation,
      map: map,
      label: 'G',
      title: 'Jouw gekozen locatie',
    });

    new window.google.maps.Polyline({
      path: [startLocation, selectedLocation],
      geodesic: true,
      strokeColor: '#FF0000',
      strokeOpacity: 1.0,
      strokeWeight: 2,
      map: map,
    });

    const bounds = new window.google.maps.LatLngBounds();
    bounds.extend(startLocation);
    bounds.extend(selectedLocation);
    map.fitBounds(bounds);
  };

  return (
    <div>
      <h1>Jouw Resultaat</h1>
      <div id="result-container">
        <div className="result-item">
          <h3>Afstand</h3>
          <p id="distance"></p>
        </div>
        <div className="result-item">
          <h3>Score</h3>
          <p id="score"></p>
        </div>
        <div className="result-item">
          <h3>Tijd</h3>
          <p id="time"></p>
        </div>
      </div>
      <div id="map-container">
        <div id="map"></div>
      </div>
      <div id="button-container">
        <button onClick={() => window.location.href='/locatie'}>Speel Opnieuw</button>
        <button onClick={() => window.location.href='/'}>Terug naar Start</button>
      </div>
    </div>
  );
};

export default Resultaat;