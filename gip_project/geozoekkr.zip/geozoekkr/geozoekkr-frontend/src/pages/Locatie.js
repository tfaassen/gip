import { useEffect, useState, useRef } from "react";

const Locatie = () => {
  const [timer, setTimer] = useState(150);
  const [selectedCoordinates, setSelectedCoordinates] = useState(null);
  const [streetViewStartCoordinates, setStreetViewStartCoordinates] = useState(null);
  const [panorama, setPanorama] = useState(null);
  const apiKey = process.env.REACT_APP_GOOGLE_MAPS_API_KEY;
  const timerInterval = useRef(null);

  useEffect(() => {
    if (!window.google) {
      const script = document.createElement("script");
      script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&callback=initMap`;
      script.async = true;
      document.body.appendChild(script);

      script.onload = () => {
        console.log("Google Maps API geladen!");
        window.initMap = initMap;
      };

      return () => {
        document.body.removeChild(script);
        clearInterval(timerInterval.current);
      };
    } else {
      initMap();
    }
  }, [apiKey]);

  function initMap() {
    if (!window.google) {
      console.error("Google Maps API is niet geladen.");
      return;
    }

    const streetViewService = new window.google.maps.StreetViewService();
    const startCoordinates = { lat: 52.379189, lng: 4.900826 };
    let map;
    let marker = null;

    function getRandomLocation() {
      const lat = (Math.random() * 180 - 90).toFixed(6);
      const lng = (Math.random() * 360 - 180).toFixed(6);
      return { lat: parseFloat(lat), lng: parseFloat(lng) };
    }

    function loadStreetView(location) {
      streetViewService.getPanorama({ location, radius: 5000 }, (data, status) => {
        if (status === window.google.maps.StreetViewStatus.OK) {
          setStreetViewStartCoordinates({
            lat: data.location.latLng.lat(),
            lng: data.location.latLng.lng(),
          });
          const panoramaInstance = new window.google.maps.StreetViewPanorama(
            document.getElementById("street-view"),
            {
              position: data.location.latLng,
              pov: { heading: 0, pitch: 0 },
              zoom: 1,
              fullscreenControl: false,
              enableCloseButton: false,
              addressControl: false,
              linksControl: false,
              showRoadLabels: false,
            }
          );
          setPanorama(panoramaInstance);
          startTimer();
        } else {
          findRandomStreetView();
        }
      });
    }

    function findRandomStreetView() {
      loadStreetView(getRandomLocation());
    }

    function startTimer() {
      timerInterval.current = setInterval(() => {
        setTimer((prev) => {
          if (prev <= 1) {
            clearInterval(timerInterval.current);
            lockStreetView();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }

    function lockStreetView() {
      if (panorama) {
        panorama.setOptions({
          disableDefaultUI: true,
          draggable: false,
          linksControl: false,
          motionTracking: false,
          motionTrackingControl: false,
          clickToGo: false,
          keyboardShortcuts: false,
        });
        alert("Tijd voorbij! Je kunt niet meer bewegen.");
      }
    }

    map = new window.google.maps.Map(document.getElementById("map"), {
      zoom: 1,
      center: startCoordinates,
      disableDefaultUI: true,
    });

    map.addListener("click", (event) => {
      if (marker) {
        marker.setPosition(event.latLng);
      } else {
        marker = new window.google.maps.Marker({
          position: event.latLng,
          map: map,
        });
      }
      setSelectedCoordinates({ lat: event.latLng.lat(), lng: event.latLng.lng() });
    });

    findRandomStreetView();
  }

  function calculateDistance(coord1, coord2) {
    const R = 6371;
    const dLat = ((coord2.lat - coord1.lat) * Math.PI) / 180;
    const dLng = ((coord2.lng - coord1.lng) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((coord1.lat * Math.PI) / 180) *
        Math.cos((coord2.lat * Math.PI) / 180) *
        Math.sin(dLng / 2) *
        Math.sin(dLng / 2);
    return R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
  }

  function handleSearch() {
    if (selectedCoordinates && streetViewStartCoordinates) {
      const distance = calculateDistance(streetViewStartCoordinates, selectedCoordinates);
      alert(`Afstand: ${distance.toFixed(2)} km`);
    }
  }

  return (
    <div>
      <div id="timer-container">
        Tijd over: <span>{Math.floor(timer / 60)}:{(timer % 60).toString().padStart(2, "0")}</span>
      </div>
      <div id="street-view" style={{ width: "100%", height: "300px" }}></div>
      <button onClick={handleSearch}>Bekijk Afstand</button>
      <div id="map" style={{ width: "100%", height: "300px" }}></div>
    </div>
  );
};

export default Locatie;
